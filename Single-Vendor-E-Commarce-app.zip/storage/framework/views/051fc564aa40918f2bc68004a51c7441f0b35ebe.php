
<?php $__env->startSection('contents'); ?>
<div class="myform">
    <form action="<?php echo e(route('admin.store.stock')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="pnn1">Product Name</label>
            <select class="form-control" id="pnn1" name="product_id">
                <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Total Produce</label>
            <input type="number" name="total_produce" class="form-control" id="exampleFormControlInput1" placeholder="Enter quantity" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit Now</button>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/admin/layouts/stock/add_stock.blade.php ENDPATH**/ ?>