
<?php $__env->startSection('contents'); ?>
<!-- Message -->
<?php if(session()->has('error')): ?>
<p class="alert alert-danger"><?php echo e(session()->get('error')); ?></p>
<?php endif; ?>
<?php if(session()->has('message')): ?>
<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
<?php endif; ?>
<!-- end -->


<div class="table_button">
    <a href="<?php echo e(route('admin.add.category')); ?>" class="btn btn-primary">Add Category</a>
</div>
<div class="manage_table">
    <table class="table table-borderless table-hover" id="myCategoryTable">
        <thead class="table-primary">
            <tr class="text-center">
                <th>SL</th>
                <th>Name</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($cat->category_name); ?></td>
                <td><img src="<?php echo e(asset('/uploads/category/'.$cat->image )); ?>" style="width:80px;height:80px;" alt=""></td>
                <td>
                    <a href="<?php echo e(route('admin.view.category',$cat->id)); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
                    <a href="<?php echo e(route('admin.edit.category',$cat->id)); ?>" class="btn btn-primary"><i class="fa fa-th-list"></i></a>
                    <a href="<?php echo e(route('admin.delete.category',$cat->id)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<!-- jquery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/jquery.dataTables.min.js" integrity="sha512-BkpSL20WETFylMrcirBahHfSnY++H2O1W+UnEEO4yNIl+jI2+zowyoGJpbtk6bx97fBXf++WJHSSK2MV4ghPcg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function() {
        $('#myCategoryTable').DataTable();
    });
</script>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/admin/layouts/category/category_table.blade.php ENDPATH**/ ?>