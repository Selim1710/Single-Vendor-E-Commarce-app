
<?php $__env->startSection('contents'); ?>
<!-- See All Categories Button -->
<section class="all-categories">
    <button class="btn w-100 text-white" style="background:#16a085;" type="button" data-toggle="collapse" data-target="#category" aria-expanded="false" aria-controls="collapseExample">
        See All Categories &rarr;
    </button>
    <div class=" collapse category p-lg-1" id="category">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="btn-group">
            <a href="#" class="btn btn-success dropdown-toggle m-1 text-uppercase" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo e($category->category_name); ?>

            </a>
            <?php if(!empty($category->subCategories)): ?>
            <div class="dropdown-menu">
                <?php $__currentLoopData = $category->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-item" href="<?php echo e(route('show.sub.category.product',$subCategory->id)); ?>"><?php echo e($subCategory->sub_category_name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<!-- Carousel  -->
<section class="product-slider">
    <div class="slider">
        <div class="row">
            <div class="col-lg-7">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <?php $__currentLoopData = $offers_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($key); ?>"></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $offers_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->first): ?>
                        <div class="carousel-item active">
                            <img class="d-block w-100" src="<?php echo e(asset('/uploads/offer/'.$offer )); ?>" alt="First slide">
                        </div>
                        <?php else: ?>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="<?php echo e(asset('/uploads/offer/'.$offer )); ?>" alt="First slide">
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
            <!-- compare product -->
            <div class="col-lg-4 mt-4">
                <div class="compare-product text-center">
                    <h3 class="pt-1">Compare Product</h3>
                    <p>Choose two product to compare</p>
                    <form action="<?php echo e(route('user.compare.product')); ?>" class="form-inline my-2 my-lg-0">
                        <input type="search" name="search_c1" value="" placeholder="Search" class="form-control m-2 w-100" aria-label="Search">
                        <input type="search" name="search_c2" value="" placeholder="Search" class="form-control m-2 w-100" aria-label="Search">
                        <br>
                        <input type="submit" class="bg-secondary p-2 border text-white w-100">
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Feature Category -->
<section class="featured-Category border">
    <div class="categoryHeader">
        <h1>Featured Category</h1>
        <p>Get Your Desired Product from Featured Category!</p>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4 col-lg-2 rounded d-flex align-items-stretch">
                <div class="card">
                    <a href="<?php echo e(route('show.category.product',$category->id)); ?>">
                        <div class="cart-img img-fluid text-center m-2">
                            <img src="<?php echo e(asset('/uploads/category/'.$category->image )); ?>" alt="" class="img-fluid">
                            <br>
                            <p class="text-center"><?php echo e($category->category_name); ?></p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <br><br><br><br><br><br>
</section>
<section class="featured-Product border">
    <div class="productHeader">
        <h1>Featured Product</h1>
        <p>Check & Get Your Desired Product !</p>
    </div>
    <div class="product">
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="column d-flex align-items-stretch">
                <div class="box">
                    <a href="<?php echo e(route('website.product.details',$product->id)); ?>">
                        <div class="img-box">
                            <img src="<?php echo e(asset('uploads/products/'.$product->product_image)); ?>" class="img-fluid">
                        </div>
                    </a>
                    <div class="detail-box">
                        <h5>
                            Model: <?php echo e($product->model); ?>

                        </h5>
                        <h6>
                            Price: <?php echo e($product->regular_price); ?>

                        </h6>
                        <a href="<?php echo e(route('add.to.cart',$product->id)); ?>" class="btn btn-primary">Add To Cart</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="text-center mb-4"><a href="<?php echo e(route('website.all.product')); ?>" class="btn text-white w-25" style="background-color: #e84393;">View All Product</a></div>
    </div>
</section>
<!-- Description -->
<section class="company-descripiton border">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center font-weight-bold mt-4">
                <h1>BGD Online Limited Services</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 p-2 text-center mt-4">
                <h3 class="text-capitalize">web hosting</h3><br>
                <div class="description">
                    <article>
                        BGD Online Limited make registration of web hosting fast, secure, affordable and secure manner. If you are looking to transfer hosting to shared, reseller , vps or dedicated server provider with superb customer support and have a 99.99% uptime.
                    </article>
                </div>
            </div>
            <div class="col-lg-12 p-2 text-center mt-4">
                <h3 class="text-capitalize">web development</h3><br>
                <div class="description">
                    <article>
                        BGD Online Limited expertise in web development. We do outsourcing web design and provide hosting services.We developcompany website , ecommerce solution, Content rich CMS web application for the business needs.You find all service in here
                    </article>
                </div>
            </div>
            <div class="col-lg-12 p-2 text-center mt-4">
                <h3 class="text-capitalize">internet connectivity </h3><br>
                <div class="description">
                    <article>
                        Internet access is the process that enables individuals and organisations to connect to the Internet using computer terminals, computers, mobile devices, sometimes via computer networks. Once connected to the Internet, users can access Internet services, such as email. </article>
                </div>
            </div>
            <div class="col-lg-12 p-2 text-center mt-4">
                <h3 class="text-capitalize">Domain Registration </h3><br>
                <div class="description">
                    <article>
                        We provide Bangladeshi .bd or .bangla and the all the popular domain registration services. Our server uptime 99.99% compared to others. We ensure high server uptime with superb support.You find all service in here
                </div>
            </div>
        </div>
    </div>
    <br><br><br><br>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Single-Vendor-E-Commarce-app\resources\views/website/layouts/home.blade.php ENDPATH**/ ?>