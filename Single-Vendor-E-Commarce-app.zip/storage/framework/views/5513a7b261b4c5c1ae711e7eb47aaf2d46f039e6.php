
<?php $__env->startSection('contents'); ?>
<!-- Message -->
<?php if(session()->has('error')): ?>
<p class="alert alert-danger"><?php echo e(session()->get('error')); ?></p>
<?php endif; ?>
<?php if(session()->has('message')): ?>
<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
<?php endif; ?>
<!-- end -->
<div class="manage_table">
    <table class="table table-borderless table-hover">
        <thead class="table-primary text-capitalize">
            <tr class="text-center">
                <th>customer id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Product id</th>
                <th>Name</th>
                <th>Model</th>
                <th>Price</th>
                <th>Offer</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Order Status</th>
                <th>Payment Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($order->customer_id); ?></td>
                <td><?php echo e($order->name); ?></td>
                <td><?php echo e($order->email); ?></td>
                <td><?php echo e($order->phone); ?></td>
                <td><?php echo e($order->product_id); ?></td>
                <td><?php echo e($order->product_name); ?></td>
                <td><?php echo e($order->model); ?></td>
                <td><?php echo e($order->price); ?></td>
                <td><?php echo e($order->offer); ?></td>
                <td><?php echo e($order->quantity); ?></td>
                <td><?php echo e($order->total); ?></td>
                <td><?php echo e($order->order_status); ?></td>
                <td><?php echo e($order->payment_status); ?></td>

                <td>
                    <?php if($order->order_status == 'pending'): ?>
                    <a href="<?php echo e(route('admin.accept.order',$order->id)); ?>" class="btn btn-success"><i class="fa fa-check"></i></a>
                    <a href="<?php echo e(route('admin.reject.order',$order->id)); ?>" class="btn btn-danger mt-1"><i class="fa fa-times"></i></a>
                    <?php elseif($order->order_status == 'canceled'): ?>
                    <a href="<?php echo e(route('admin.accept.order',$order->id)); ?>" class="btn btn-success"><i class="fa fa-check"></i></a>
                    <?php elseif($order->order_status == 'accepted'): ?>
                    <a href="<?php echo e(route('admin.reject.order',$order->id)); ?>" class="btn btn-danger mt-1"><i class="fa fa-times"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/admin/layouts/order/order_table.blade.php ENDPATH**/ ?>