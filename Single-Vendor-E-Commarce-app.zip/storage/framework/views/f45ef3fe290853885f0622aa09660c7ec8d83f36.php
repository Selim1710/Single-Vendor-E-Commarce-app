
<?php $__env->startSection('contents'); ?>

<!-- title -->
<section class="Laptop-Deal-title"> <br>
    <div class="container">
        <div class="title text-center p-4 border border-dark">
            <p>স্টার টেক অনলাইন শপ অথবা যেকোন আউটলেট থেকে Palit, MSI, ASUS সহ

                জনপ্রিয় সব ব্র্যান্ডের গ্রাফিক্স কার্ড কিনলেই পাচ্ছেন সর্বোচ্চ ৯৫০০ টাকা পর্যন্ত মূল্যছাড়! এছাড়াও সর্বোচ্চ ২৭০০০ টাকা মূল্যছাড়ে পাচ্ছেন আকর্ষনীয় সব ট্যাবলেট।
            </p> <br><br>
            <h2>অফারের পণ্যগুলো দেখতে নিচে স্ক্রল করুন &nbsp; ⬇️</h2>
        </div>
    </div>
</section>
<!-- laptop -->
<section class="featured-Category">
    <div class="categoryHeader">
        <h1>Ramadan Laptop Mega Deal</h1>
        <p>Get exciting discount on Graphics Card</p>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $laptopDeals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-lg-3 d-flex align-items-stretch">
                <div class="card">
                    <div class="card-body font-weight-bold">
                        <p class="p-1 text-white rounded" style="background:#40739e;">
                            Save: <?php echo e($deal['regular_price']-($deal['product_offer']/100)); ?> ৳
                        </p>
                        <a href="<?php echo e(route('website.deals.details',$deal->id)); ?>" style="color:black;">
                            <img src="<?php echo e(asset('uploads/products/'.$deal->product_image)); ?>" alt="" class="img-fluid"><br><br>
                            <p>Model: <?php echo e($deal->model); ?></p>
                            <span class="text-danger">Price: <?php echo e($deal->regular_price); ?> ৳</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <br><br><br><br>
</section>
<!-- tablet -->
<section class="featured-Product border">
    <div class="productHeader">
        <h1>Ramadan Tablet Mega Deal</h1>
        <p>Get exciting discount on Tablets</p>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $tabletDeals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-lg-3 d-flex align-items-stretch">
                <div class="card">
                    <div class="card-body font-weight-bold">
                        <!-- save money -->
                        <p class="p-1 text-white rounded" style="background:#40739e;">
                            Save: <?php echo e($deal['regular_price']-($deal['product_offer']/100)); ?> ৳
                        </p>
                        <a href="<?php echo e(route('website.deals.details',$deal->id)); ?>" style="color:black;">
                            <img src="<?php echo e(asset('uploads/products/'.$deal->product_image)); ?>" alt="" class="img-fluid"><br><br>
                            <p>Model: <?php echo e($deal->model); ?></p>
                            <span class="text-danger">Price: <?php echo e($deal->regular_price); ?> ৳</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <br><br><br><br>
</section>

<!-- Description -->

<section class="descripiton">
    <div class="container">
        <h4 class="text-danger p-1 mt-4">ডিল ক্যাম্পেইনের শর্তাবলী: </h4>

        <article>
            Ramadan ডিল ক্যাম্পেইন এর কোনো পণ্যে অন্য কোনো অফার থাকলে তা প্রযোজ্য হবে না।
            Ramadan ডিল ক্যাম্পেইন এর পণ্য অবশ্যই অনলাইনে অর্ডার করতে হবে।
            বিকাশ পেমেন্টে একজন ক্রেতা ১ দিনে সর্বোচ্চ ২০০ টাকা এবং অফার চলাকালীন সময়ে সর্বোচ্চ ৩০০ টাকা পর্যন্ত ক্যাশব্যাক উপভোগ করতে পারবেন।
            নগদ পেমেন্টে অফার চলাকালীন সময়ে একজন ক্রেতা সর্বোচ্চ ৪০০ টাকা পর্যন্ত ক্যাশব্যাক উপভোগ করতে পারবেন।
            ক্যাশব্যাক অফারটি শুধুমাত্র বিকাশ / নগদ -এর গেটওয়ে পেমেন্টের ক্ষেত্রে প্রযোজ্য।
            Ramadan ক্যাম্পেইনের পণ্যসমূহে ফ্রি ডেলিভারি অফার প্রযোজ্য নয়। অর্ডারের পর ক্রেতাকে কল করে ডেলিভারি সংক্রান্ত সকল তথ্য জানিয়ে দেয়া হবে।
            কোন সঙ্গত কারনে এই ক্যাম্পেইনের পেমেন্ট রিফান্ড করা হলে তা সাধারণ রিফান্ড পলিসি প্রক্রিয়ায় সম্পন্ন হবে। এক্ষেত্রে ক্রেতা যে এমাউন্ট পেমেন্ট করেছে শুধুমাত্র তারই রিফান্ড প্রসেস করা হবে।
        </article>
    </div><br><br><br>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/website/layouts/laptop_deals.blade.php ENDPATH**/ ?>