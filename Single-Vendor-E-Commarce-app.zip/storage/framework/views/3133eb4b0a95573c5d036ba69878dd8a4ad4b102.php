
<?php $__env->startSection('contents'); ?>
<!-- Validation Error Message -->
<div class="message">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</div>

<div class="myform">
    <form action="<?php echo e(route('admin.store.category')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="c_n1">Category Name</label>
            <input type="text" name="category_name" class="form-control" id="c_n1" placeholder="Enter Category Name" required>
        </div>
        <div class="form-group">
            <label for="img1">Category Image</label>
            <input type="file" name="image" accept="image/*" class="form-control" id="img1" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit Now</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/admin/layouts/category/add_category.blade.php ENDPATH**/ ?>