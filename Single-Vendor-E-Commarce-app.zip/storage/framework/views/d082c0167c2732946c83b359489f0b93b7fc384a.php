
<?php $__env->startSection('contents'); ?>
<!-- style="border:5px solid red;" -->
<!-- Product Offer Details  -->
<section class="product-offer">
    <div class="container">
        <div class="offer text-center">
            <br><br>
            <div class="time d-flex">
                <span class="title text-uppercase">offers ends in</span>
                <div class="time-details">
                    <span class="digit">0</span>
                    <span class="digit">1</span><br>
                    <span class="tag pr-2">Days</span>
                </div>
                <div class="time-details">
                    <span class="digit">0</span>
                    <span class="digit">1</span><br>
                    <span class="tag pr-2">Hour</span>
                </div>
                <div class="time-details">
                    <span class="digit">1</span>
                    <span class="digit">1</span><br>
                    <span class="tag pr-2">Minute</span>
                </div>
                <div class="time-details">
                    <span class="digit">1</span>
                    <span class="digit">0</span><br>
                    <span class="tag pr-2">Seconds</span>
                </div>
            </div>
            <br><br>
            <div class="offer-details">
                <img src="<?php echo e(asset('/uploads/offer/'.$offer->image)); ?>" class="w-100 h-75"><br><br>
                <p>
                    <?php echo e($offer->details); ?>

                </p>
                <span class="text-secondary">
                <?php echo e($offer->condition); ?>

                </span>
            </div>
            <br> <br>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/website/layouts/offer_details.blade.php ENDPATH**/ ?>