
<?php $__env->startSection('contents'); ?>
<div class="myform">
    <!-- Validation Error Message -->
    <div class="message">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>

    <form action="<?php echo e(route('admin.store.subCategory')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="sun1">Sub-Category Name</label>
            <input type="text" name="sub_category_name" class="form-control" id="sun1" placeholder="Enter Subcategory Name" required>
        </div>
        <div class="form-group">
            <label for="cni1">Category Name</label>
            <select class="form-control" id="cni1" name="category_id">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->category_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Submit Now</button>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/admin/layouts/subCategory/add_subCategory.blade.php ENDPATH**/ ?>