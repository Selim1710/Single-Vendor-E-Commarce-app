
<?php $__env->startSection('contents'); ?>
<!-- featured product -->

<section class="featured-Product border">
    <div class="productHeader">
        <h1> See Our Offers</h1>
        <p class="text-center">অফারের অফারগুলো দেখতে নিচে স্ক্রল করুন &nbsp;⬇️</p>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-lg-6">
                <div class="card text-center">
                    <div class="card-body">
                        <a href="#" style="color:black;">
                            <img src="<?php echo e(asset('/uploads/offer/'.$offer->image)); ?>" alt="" class="img-fluid w-100"><br><br>
                            <p><?php echo e($offer->title); ?></p>
                        </a>
                        <span class="text-secondary font-italic"><?php echo e($offer->short_details); ?></span> <br><br>
                        <a href="<?php echo e(route('website.offer.details',$offer->id)); ?>" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <br><br>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/website/layouts/offers.blade.php ENDPATH**/ ?>