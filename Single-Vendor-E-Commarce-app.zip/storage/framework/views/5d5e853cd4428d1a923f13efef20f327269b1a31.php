
<?php $__env->startSection('contents'); ?>

<div class="table_button text-center">
    <h1>Customer List</h1>
</div>
<!-- Message -->
<?php if(session()->has('error')): ?>
<p class="alert alert-danger"><?php echo e(session()->get('error')); ?></p>
<?php endif; ?>
<?php if(session()->has('message')): ?>
<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
<?php endif; ?>
<!-- end -->
<div class="manage_table">
    <table class="table table-borderless table-hover" id="customer_table">
        <thead class="table-primary">
            <tr class="text-center">
                <th>Name</th>
                <th>email</th>
                <th>phone</th>
                <th>Address</th>
                <th class="bg-warning"><span class="text-success">Inable</span> / <span class="text-danger">Disable</span></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td><?php echo e($user->address); ?></td>
                <td>
                    <?php if($user->status != 'disabled'): ?>
                    <a href="<?php echo e(route('admin.ban.customer',$user->id)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('admin.un.ban.customer',$user->id)); ?>" class="btn btn-success"><i class="fa fa-check"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<!-- jquery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/jquery.dataTables.min.js" integrity="sha512-BkpSL20WETFylMrcirBahHfSnY++H2O1W+UnEEO4yNIl+jI2+zowyoGJpbtk6bx97fBXf++WJHSSK2MV4ghPcg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function() {
        $('#customer_table').DataTable();
    });
</script>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Single-Vendor-E-Commarce-app\resources\views/admin/layouts/customer/customer_table.blade.php ENDPATH**/ ?>