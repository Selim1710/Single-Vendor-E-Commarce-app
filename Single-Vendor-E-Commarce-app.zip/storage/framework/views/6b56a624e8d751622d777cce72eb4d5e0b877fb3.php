
<?php $__env->startSection('contents'); ?>
<!-- Added, Edit, Delete Message -->
<?php if(session()->has('error')): ?>
<p class="alert alert-danger"><?php echo e(session()->get('error')); ?></p>
<?php endif; ?>
<?php if(session()->has('message')): ?>
<p class="alert alert-success"><?php echo e(session()->get('message')); ?></p>
<?php endif; ?>
<!-- end -->
<div class="table_button">
    <a href="<?php echo e(route('admin.add.product')); ?>" class="btn btn-primary">Add Product</a>
</div>
<div class="manage_table">
    <table class="table table-borderless table-hover">
        <thead class="table-primary">
            <tr class="text-center">
                <th>SL</th>
                <th>Model</th>
                <th>Name</th>
                <th>Regular Price</th>
                <th>Image</th>
                <th>Offer</th>
                <th>Product Description</th>
                <!-- specification -->
                <th>processor</th>
                <th>display</th>
                <th>memory</th>
                <th>storage</th>
                <th>graphics</th>
                <th>operating_system</th>
                <th>battery</th>
                <th>adapter</th>
                <th>audio</th>
                <th>keyboard</th>
                <th>optical_drive</th>
                <th>webcam</th>
                <th>wifi</th>
                <th>bluetooth</th>
                <th>USB</th>
                <th>HDMI</th>
                <th>VGA</th>
                <th>audio_jack_combo</th>
                <th>dimensions</th>
                <th>weight</th>
                <th>colors</th>
                <th>manufacturing_warranty</th>

                <th>subCategory_id</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($product->model); ?></td>
                <td><?php echo e($product->product_name); ?></td>
                <td><?php echo e($product->regular_price); ?></td>
                <td> <img src="<?php echo e(asset('/uploads/products/'.$product->product_image )); ?>" style="width:80px;height:80px;" alt=""> </td>
                <td><?php echo e($product->product_offer); ?> %</td>
                <td><?php echo e($product->product_description); ?></td>
                <!-- specification -->
                <td><?php echo e($product->processor); ?></td>
                <td><?php echo e($product->display); ?></td>
                <td><?php echo e($product->memory); ?></td>
                <td><?php echo e($product->storage); ?></td>
                <td><?php echo e($product->graphics); ?></td>
                <td><?php echo e($product->operating_system); ?></td>
                <td><?php echo e($product->battery); ?></td>
                <td><?php echo e($product->adapter); ?></td>
                <td><?php echo e($product->audio); ?></td>
                <td><?php echo e($product->keyboard); ?></td>
                <td><?php echo e($product->optical_drive); ?></td>
                <td><?php echo e($product->webcam); ?></td>
                <td><?php echo e($product->wifi); ?></td>
                <td><?php echo e($product->bluetooth); ?></td>
                <td><?php echo e($product->USB); ?></td>
                <td><?php echo e($product->HDMI); ?></td>
                <td><?php echo e($product->VGA); ?></td>
                <td><?php echo e($product->audio_jack_combo); ?></td>
                <td><?php echo e($product->dimensions); ?></td>
                <td><?php echo e($product->weight); ?></td>
                <td><?php echo e($product->colors); ?></td>
                <td><?php echo e($product->manufacturing_warranty); ?></td>

                <td><?php echo e($product->subCategory_id); ?></td>
                <td><?php echo e($product->category_id); ?></td>

                <td>
                    <a href="<?php echo e(route('admin.view.product',$product->id)); ?>" class="btn btn-success"><i class="fa fa-eye"></i></a>
                    <a href="<?php echo e(route('admin.edit.product',$product->id)); ?>" class="btn btn-primary mt-1"><i class="fa fa-th-list"></i></a>
                    <a href="<?php echo e(route('admin.delete.product',$product->id)); ?>" class="btn btn-danger mt-1"><i class="fa fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/admin/layouts/product/product_table.blade.php ENDPATH**/ ?>