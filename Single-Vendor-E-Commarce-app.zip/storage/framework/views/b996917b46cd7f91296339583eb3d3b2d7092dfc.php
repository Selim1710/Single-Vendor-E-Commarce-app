
<?php $__env->startSection('contents'); ?>
<section class="featured-Product border" id="featured_product">
    <div class="productHeader">
        <h1>Our Products</h1>
        <p>Check & Get Your Desired Product !</p>
    </div>
    <div class="product">
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="column">
                <div class="box">
                    <a href="<?php echo e(route('website.product.details',$product->id)); ?>">
                        <div class="img-box">
                            <img src="<?php echo e(asset('uploads/products/'.$product->product_image)); ?>" class="img-fluid">
                        </div>
                    </a>
                    <div class="detail-box">
                        <h5>
                            Model: <?php echo e($product->model); ?>

                        </h5>
                        <h6>
                            Price: <?php echo e($product->regular_price); ?>

                        </h6>
                        <a href="<?php echo e(route('add.to.cart',$product->id)); ?>" class="btn btn-primary">Add To Cart</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Single-Vendor-E-Commarce-app\resources\views/website/layouts/search.blade.php ENDPATH**/ ?>