
<?php $__env->startSection('contents'); ?>
<!-- Validation Error Message -->
<div class="message">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</div>

<div class="myform">
    <form action="<?php echo e(route('admin.store.offer')); ?>" method="POST" enctype="multipart/form-data" class="text-capitalize">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="deadline">deadline</label>
            <input type="datetime-local" name="deadline" class="form-control w-25" id="deadline"required>
        </div>
        <div class="form-group">
            <label for="t1">title</label>
            <input type="text" name="title" class="form-control" id="t1" placeholder="Enter Branch Name & Offer" required>
        </div>
        <div class="form-group">
            <label for="short_details">short details</label>
            <input type="text" name="short_details" class="form-control" id="short_details" placeholder="Must be within 30 letter" required>
        </div>
        <div class="form-group">
            <label for="image">image</label>
            <input type="file" name="image" class="form-control" id="image" required>
        </div>
        <div class="form-group">
            <label for="details">Details</label>
            <textarea name="details" id="details" class="form-control" required></textarea>
        </div>
        <div class="form-group">
            <label for="condition">condition</label>
            <textarea name="condition" id="condition" class="form-control" required></textarea>
            <button type="submit" class="btn btn-primary w-100">Submit Now</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\SVC\Single-Vendor-E-Commarce-app\resources\views/admin/layouts/offer/add_offer.blade.php ENDPATH**/ ?>