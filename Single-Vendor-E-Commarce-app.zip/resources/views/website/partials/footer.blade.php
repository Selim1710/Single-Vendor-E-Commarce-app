<section class="companyDescripton">
    <div class="footerD">
        <div class="support text-center">
            <h4>SUPPORT</h4>
            <div class="time">
                <h5>Time: 10.00am to 06.00pm</h5>
            </div>
            <div class="contact">
                <h5>Contact: 016........</h5>
            </div>
        </div>
        <div class="about-us text-center">
            <h4>ABOUT US </h4>
            <a href="{{ route('user.refund.policy') }}">Refund Policy</a>
            <a href="{{ route('user.terms.&.conditions') }}" class="ml-2">Terms & Condition</a>
        </div>
        <div class="stay-connected text-center">
            <h4>STAY CONNECTED </h4>
            <p>BGD online limited <br>
                Phone : +88 019-72379494 <br>
                Landline : : +88 02-8090528 <br>
                Email : info@bgdonline.net <br>
                Address : 820, Mamun Tower(8th floor),
                Shewrapara, Mirpur, Dhaka-1216
            </p>
        </div>
    </div>
</section>